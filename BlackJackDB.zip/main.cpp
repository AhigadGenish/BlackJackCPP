#include "Game.h"
#include "Sql.h"
//Ahigad Genish

int Player::_numOfPlayers = 0;
void main()
{
	srand(time(0));
	cout << "Running 'SELECT 'Hello World!' � 'AS _message'..." << endl;
	cout << "connecting to server .. " << endl;
	try {
		sql::Driver* driver;
		sql::Connection* con;
		sql::PreparedStatement* prep_stmt;



		/* Create a connection */
		driver = get_driver_instance();
		con = driver->connect("tcp://127.0.0.1:3306", "root", "12345678");
		/* Connect to the MySQL test database */
		con->setSchema("bjusers");
		menu();
		delete con;
	}
	catch (sql::SQLException& e) {
		cout << "# ERR: SQLException in " << endl;
		cout << "(" << endl << ") on line " << endl;
		cout << "# ERR: " << e.what();
		cout << " (MySQL error code: " << e.getErrorCode();
		cout << ", SQLState: " << e.getSQLState() << " )" << endl;
	}
};

