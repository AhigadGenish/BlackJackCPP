#include "Player.h"

void Player::setSplitChoice()
{
	bool splitChoice;
	cout << this->getName() << endl;
	cout << "Do you want to split ? for yes insert 1 for no insert 0 " << endl;
	cin >> splitChoice;
	this->_splitChoice = splitChoice;
}
bool Player::setPlayer(int money, int min)
{
	if (money < min)
	{
		cout << this->getName() << " " << min << " $ minimum for bet please" << endl;
		return false;
	}
	else
		return true;
}
void Player::setInsuranceChoice()
{
	bool insuranceChoice;
	cout << this->getName() << endl;
	cout << "Insurance ? for yes insert 1 for no insert 0 " << endl;
	cin >> insuranceChoice;
	if (this->getTotalMoney() - this->getHand(0)->getMoney() < 0.5 * this->getHand(0)->getMoney())
	{
		cout << "No enough money for insurance" << endl;
		this->_insuranceChoice = false;
		return;
	}
	this->_insuranceChoice = insuranceChoice;
	if (insuranceChoice)
	{
		this->setMoneyInsurance(0.5);
		this->printPlayer(false);
	}
}
void  Player::setMoneyInsurance(double mul)
{
	if (this->getInsuranceChoice())
		if (this->getMoneyInsurance() == 0)
		{
			this->_moneyInsurance = mul * this->getHand(0)->getMoney();
			return;
		}
		else
			this->_moneyInsurance *= mul;
}
void Player::checkSplit()
{
	if (this->_hands[0]->getCanSplit())
	{
		this->setSplitChoice();
		this->setSplit();
	}
}
void Player::setName(string name)
{
	this->_name = name;
}
void Player::setSplit()
{
	if (this->getSplitChoice())
		if (this->getTotalMoney() >= 2 * this->_hands[0]->getMoney())
			this->_hands[1] = new Hand(this->_hands[0]->HandSplit(this->_hands[0]->getCard1(), this->_hands[0]->getCard2()));
		else
			cout << "Minimum " << this->_hands[0]->getMoney() << "$ for the second hand" << endl;
	else
		return;

	for (int i = 0; i < 2;i++)
	{
		if (this->_hands[i] != NULL)
		{
			cout << "Hand " << (i + 1) << ":" << endl;
			this->_hands[i]->printHand(false);
			cout << "  ";
		}

	}
}
int Player::decisionAfter(Hand& hand)
{
	int decisionAfter = 0;
	cout << this->getName() << endl;
	cout << "For stand press 0,hit 3" << endl;
	cin >> decisionAfter;
	switch (decisionAfter)
	{
	case 0:
	{
		break;
	}
	case 3:
	{
		hand.setMoreCard(true);
		break;
	}
	default:
		break;

	}
	return decisionAfter;
}
void Player::setId(int id) {
	this->_id = id;
}
int Player::decision(Hand& hand)
{
	int decision = 0;
	cout << "For stand press 0, double press 1 , surrender press 2 ,  hit 3" << endl;
	cin >> decision;
	switch (decision)
	{


	case 1:
	{
		if (this->getTotalMoney() < 2 * hand.getMoney())
		{
			cout << "no enough money for double" << endl;
			return 3;
		}
		else
			hand.setHandMoney(2);
		break;
	}
	case 2:
	{
		hand.setHandMoney(0.5);
		break;
	}
	case 3:
	{
		break;
	}
	default:
		break;
	}
	return decision;
}
void Player::setTotalMoney(int money)
{
	this->_totalMoney += money;
}
void Player::calculateMoney()
{
	try {
		sql::Driver* driver;
		sql::Connection* con;
		sql::PreparedStatement* prep_stmt;


		/* Create a connection */
		driver = get_driver_instance();
		con = driver->connect("tcp://127.0.0.1:3306", "root", "12345678");
		/* Connect to the MySQL test database */
		con->setSchema("bjusers");
		this->setTotalMoney(getMoneyInsurance());
	
		if (this->getHand(0) != NULL) {
			updateNumOfGames(con, this->getId());
			this->getHand(0)->setProfit(getMoneyInsurance());
		}
		for (int i = 0;i < 2;i++)
		{

			if (this->getHand(i) != NULL)
			{
				if (this->getHand(i)->getWin() && this->getHand(i)->getSumOfCardsAce() == 21 && this->getHand(i)->getNumOfMoreCards() == 0)
				{   // win
					updateNumOfWin(con,this->getId());
					this->getHand(i)->setHandMoney(1.5);
					this->setTotalMoney(this->getHand(i)->getMoney());
					this->getHand(0)->setProfit(this->getHand(i)->getMoney());

				}
				else if ((this->getHand(i)->getWin() && this->getHand(i)->getSumOfCardsAce() == 21 && this->getHand(i)->getNumOfMoreCards() != 0))
				{  //win
					updateNumOfWin(con, this->getId());
					this->getHand(i)->setHandMoney(1);
					this->setTotalMoney(this->getHand(i)->getMoney());
					this->getHand(0)->setProfit(this->getHand(i)->getMoney());

				}
				else if (this->getHand(i)->getWin() && !(this->getHand(i)->getSumOfCardsAce() == 21))

				{ // win
					updateNumOfWin(con, this->getId());
					this->getHand(i)->setHandMoney(1);
					this->setTotalMoney(this->getHand(i)->getMoney());
					this->getHand(0)->setProfit(this->getHand(i)->getMoney());

				}
				else if (this->getHand(i)->getDrow() && !this->getHand(i)->getFail())
				{
					//tie
					updateNumOfTie(con, this->getId());
					this->getHand(i)->setHandMoney(0);
					this->getHand(0)->setProfit(this->getHand(i)->getMoney());

				}
				else if (this->getHand(i)->getFail() || (!this->getHand(i)->getWin() && !this->getHand(i)->getDrow()))
				{ // lose
					updateNumOfLose(con, this->getId());
					this->getHand(i)->setHandMoney(-1);
					this->setTotalMoney(this->getHand(i)->getMoney());
					this->getHand(0)->setProfit(this->getHand(i)->getMoney());

				}
			}
		}

		delete con;

	}
	
	
	catch (sql::SQLException& e) {
		cout << "# ERR: SQLException in " << endl;
		cout << "(" << endl << ") on line " << endl;
		cout << "# ERR: " << e.what();
		cout << " (MySQL error code: " << e.getErrorCode();
		cout << ", SQLState: " << e.getSQLState() << " )" << endl;
	}
}
void Player::setMinBet(int min)
{
	this->_minBet = min;
}
bool Player::canPlay() const
{
	if (this->getTotalMoney() >= this->getMinBet())
		return true;
	else
		return false;
}

bool Player::moreCard(Hand& hand, int decision)
{
	bool flag = false;
	switch (decision)
	{
	case 1:
	{
		hand.setMoreCard(true);
		flag = true;
		break;
	}

	case 2:
	{
		hand.eraseHand();
		break;

	}
	case 3:
	{
		hand.setMoreCard(true);
		break;
	}

	default:
		break;
	}
	return flag;
}
void Player::printPlayer(bool beAfter)
{
	cout << "Name: " << this->getName() << " Total Money: " << this->getTotalMoney() << "$" << endl;
	if (this->getMoneyInsurance())
	{
		cout << "Insurance: ";
		if (beAfter && this->getMoneyInsurance() >=0)
			cout << "+";
		cout << this->getMoneyInsurance() << "$" << endl;
	}
	for (int i = 0; i < 2;i++)
	{
		if (this->_hands[i] != NULL)
		{
			cout << "Hand " << (i + 1) << ":" << endl;
			this->getHand(i)->printHand(beAfter);
			cout << "  ";
		}

	}
}

void Player::setNewHand(int m)
{
	this->getTheHand(0).newCards(m);
	this->_hands[1] = NULL;
}

Player::Player(int min, string name, int money , int id)
{
	int Handmoney = 0;
	this->setId(id);
	this->setMinBet(min);
	this->setName(name);
	this->_insuranceChoice = false;
	this->_totalMoney = money;
	for (int i = 0; i < 2; i++)
	{
		this->_hands[i] = NULL;

	}

	if (setPlayer(money, min) == true && money != 0)
	{

		cout << "Hello " << name << endl;
		cout << "Insert money for get Hand (minimun " << min << "$)" << endl;
		cin >> Handmoney;
		while (Handmoney != 0 && Handmoney < min)
		{
			cout << "Minimum " << min << "$ please " << endl;
			cin >> Handmoney;
		}
		while (Handmoney > money)
		{
			cout << "This is more than you actualy have,please enter again" << endl;
			cin >> Handmoney;
		}
		if (Handmoney != 0)
		{
			this->_hands[0] = new Hand(Handmoney);
			this->_moneyInsurance = 0;
		}
		else
			this->_hands[0] = NULL;


	}
	this->_numOfPlayers++;
}
Player :: ~Player()
{
	for (int i = 0;i < 2;i++)
	{
		if (this->_hands[i] != NULL)
			delete this->_hands[i];
	}
}