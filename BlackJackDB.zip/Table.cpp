#include "Table.h"
#include<string>

void Table::printDealerCardsFirst() const
{
	int card1 = this->_dealerHand.getCard1();
	int card2 = this->_dealerHand.getCard2();
	string cd1 = "X";
	string cd2 = "X";
	switch (card1)
	{
	case 1:
		cd1 = 'A';
		break;
	case 2:
		cd1 = '2';
		break;
	case 3:
		cd1 = '3';
		break;
	case 4:
		cd1 = '4';
		break;
	case 5:
		cd1 = '5';
		break;
	case 6:
		cd1 = '6';
		break;
	case 7:
		cd1 = '7';
		break;
	case 8:
		cd1 = '8';
		break;
	case 9:
		cd1 = '9';
		break;
	case 10:
		cd1 = "10";
		break;
	case 11:
		cd1 = 'J';
		break;
	case 12:
		cd1 = 'Q';
		break;
	case 13:
		cd1 = 'K';
		break;
	default:
		cd1 = "X";
		break;
	}
	cout << cd1 << cd2 << endl;
}
void Table::printDealerCardsLast() const
{
	int card1 = this->_dealerHand.getCard1();
	string cd1 = "X";
	int card2 = this->_dealerHand.getCard2();
	string cd2 = "X";
	switch (card1)
	{
	case 1:
		cd1 = 'A';
		break;
	case 2:
		cd1 = '2';
		break;
	case 3:
		cd1 = '3';
		break;
	case 4:
		cd1 = '4';
		break;
	case 5:
		cd1 = '5';
		break;
	case 6:
		cd1 = '6';
		break;
	case 7:
		cd1 = '7';
		break;
	case 8:
		cd1 = '8';
		break;
	case 9:
		cd1 = '9';
		break;
	case 10:
		cd1 = "10";
		break;
	case 11:
		cd1 = 'J';
		break;
	case 12:
		cd1 = 'Q';
		break;
	case 13:
		cd1 = 'K';
		break;
	default:
		cd1 = "X";
		break;
	}

	switch (card2)
	{
	case 1:
		cd2 = 'A';
		break;
	case 2:
		cd2 = '2';
		break;
	case 3:
		cd2 = '3';
		break;
	case 4:
		cd2 = '4';
		break;
	case 5:
		cd2 = '5';
		break;
	case 6:
		cd2 = '6';
		break;
	case 7:
		cd2 = '7';
		break;
	case 8:
		cd2 = '8';
		break;
	case 9:
		cd2 = '9';
		break;
	case 10:
		cd2 = "10";
		break;
	case 11:
		cd2 = 'J';
		break;
	case 12:
		cd2 = 'Q';
		break;
	case 13:
		cd2 = 'K';
		break;
	default:
		cd2 = "X";
		break;
	}

	cout << "Dealer Cards:" << cd1 << " " << cd2 << " ";
	if (this->_dealerHand.getSumOfCardsAce() == 21 && this->_dealerHand.getMoreCards() == NULL)
	{
		cout << endl;
		cout << "Dealer BlackJack!" << endl;
		return;
	}
	if (this->_dealerHand.getMoreCards() != NULL)
	{
		string arr[20];
		for (int k = 0;k < (this->_dealerHand.getNumOfMoreCards()); k++)
		{
			switch (this->_dealerHand.getMoreCards()[k])
			{
			case 1:
				arr[k] = 'A';
				break;
			case 2:
				arr[k] = '2';
				break;
			case 3:
				arr[k] = '3';
				break;
			case 4:
				arr[k] = '4';
				break;
			case 5:
				arr[k] = '5';
				break;
			case 6:
				arr[k] = '6';
				break;
			case 7:
				arr[k] = '7';
				break;
			case 8:
				arr[k] = '8';
				break;
			case 9:
				arr[k] = '9';
				break;
			case 10:
				arr[k] = "10";
				break;
			case 11:
				arr[k] = 'J';
				break;
			case 12:
				arr[k] = 'Q';
				break;
			case 13:
				arr[k] = 'K';
				break;
			default:
				arr[k] = "X";
				break;
			}
		}
		for (int i = 0;i < (this->_dealerHand.getNumOfMoreCards());i++)
			cout << arr[i] << "	";
	}
	cout << endl;
	cout << "***************" << endl;
}
void Table::printTable() const
{
	cout << "Welcome to our Table" << endl;
	cout << "***************" << endl;
	cout << " Dealer cards: " << endl;
	printDealerCardsFirst();
	cout << "***************" << endl;
	cout << " Players : " << endl;
	for (int i = 0;i < 4;i++)
	{
		if (this->_players[i] != NULL)
		{

			cout << "Player" << i + 1 << " :";
			this->_players[i]->printPlayer(false);
			cout << "  ";

		}
	}
}
bool Table::setInsurance(int card)
{
	if (card == 1)
		return true;
	else
		return false;
}
bool Table::setDealerCards()
{
	bool flag = false;
	if (this->_dealerHand.getSumOfCardsAce() == 21)
		return flag;
	else if (this->_dealerHand.getSumOfCardsAce() < 17 && this->_dealerHand.getSumOfCards() < 17)
		for (int i = 0;i < 4;i++)
		{
			if (!flag)
			{
				if (this->getPointerTable(i) != NULL)
					for (int k = 0;k < 2;k++)
						if (this->getIndexInTable(i).getHand(k) != NULL)
							if ((!(this->getIndexInTable(i).getHand(k)->getFail()) && !((this->getIndexInTable(i).getHand(k)->getSumOfCardsAce() == 21 && this->getIndexInTable(i).getHand(k)->getNumOfMoreCards() == 0))))
							{
								flag = true;
								break;
							}
			}
			else
				break;
		}

	this->_dealerHand.setMoreCard(flag);
	return flag;
}
void Table::setTable(Player& A, int chair)
{
	this->_players[chair] = new Player(A);
}


void Table::setGame()
{
	for (int i = 0;i < 4;i++)
	{
		if (this->getPointerTable(i) != NULL)
			for (int k = 0;k < 2;k++)
				if (this->getPointerTable(i)->getHand(k) != NULL)
				{
					if (this->getIndexInTable(i).getHand(0)->getMoney() > 0)
					{
						this->_anyPlayer = true;
						return;
					}
				}
	}
}
void Table::runGame()
{
	bool aceDealer = this->getDealer().getCard1() == 1;
	bool blackJackDealer = this->getDealer().getSumOfCardsAce() == 21;
	bool flag = false;
	setGame();
	if (!this->_anyPlayer)
		return;
	if (this->setInsurance(this->getDealer().getCard1()))
		for (int i = 0;i < 4;i++)
			if (this->getPointerTable(i) != NULL)
				this->getPointerTable(i)->setInsuranceChoice();

	if ((aceDealer && blackJackDealer))
	{
		flag = true;
	}
	if (!flag) {
		for (int i = 0;i < 4;i++)
		{
			if (this->getPointerTable(i) != NULL)
			{
				cout << endl;
				cout << "Turn of " << this->getIndexInTable(i).getName() << ":" << endl;
				this->getIndexInTable(i).printPlayer(false);


				for (int k = 0;k < 2;k++)
				{
					if (this->getIndexInTable(i).getHand(k) != NULL)
					{
						if (this->getIndexInTable(i).getHand(k)->getSumOfCardsAce() != 21)
						{

							if (k == 0)
								this->getIndexInTable(i).checkSplit();

							if (this->getIndexInTable(i).getHand(k)->getSumOfCardsAce() != 21)
								setHandTurn(i, k);

						}
					}

				}
			}

		}
	}

	this->printDealerCardsLast();
	if (!flag)
		switchTurn();
}
void Table::setHandTurn(int i, int k)
{

	cout << "Hand " << k + 1 << ":" << endl;
	int decision = (this->getIndexInTable(i).decision(*(this->getIndexInTable(i).getHand(k))));
	if (decision == 0)
	{
		this->getIndexInTable(i).printPlayer(false);
		return;
	}
	else if (decision == 2)
	{
		this->getIndexInTable(i).moreCard(*(this->getIndexInTable(i).getHand(k)), 2);
		this->getIndexInTable(i).getHand(k)->setFail();
		this->getIndexInTable(i).printPlayer(false);
		return;
	}
	else if (decision == 1)
	{
		this->getIndexInTable(i).moreCard(*(this->getIndexInTable(i).getHand(k)), 1);
		this->getIndexInTable(i).getHand(k)->setFail();
		this->getIndexInTable(i).printPlayer(false);
		return;
	}
	else if (decision == 3)
	{
		this->getIndexInTable(i).moreCard(*(this->getIndexInTable(i).getHand(k)), 3);
		this->getIndexInTable(i).getHand(k)->setFail();
		this->getIndexInTable(i).printPlayer(false);
		while (!(this->getIndexInTable(i).getHand(k)->getSumOfCardsAce() == 21) && (!(this->getIndexInTable(i).getHand(k)->getSumOfCards() == 21)) && (!this->getIndexInTable(i).getHand(k)->getFail()) && this->getIndexInTable(i).decisionAfter(*(this->getIndexInTable(i).getHand(k))))
		{

			this->getIndexInTable(i).getHand(k)->setFail();
			this->getIndexInTable(i).printPlayer(false);
		}
	}
}
int Table::maxFunc(int r, int n)
{
	if (r > n && r <= 21)
		return r;
	else if (n > r && n <= 21)
		return n;
	else if (n < r && n <= 21)
		return n;
	else
		return n;
}
void Table::switchTurn()
{
	if (this->setDealerCards())
	{
		this->printDealerCardsLast();
		this->getDealer().setFail();
		while ((this->getSumOfDealerCardsAce() < 17 || this->getSumOfDealerCardsAce() > 21) && (this->getSumOfDealerCards() < 17))
		{
			this->getDealer().setMoreCard(true);
			this->getDealer().setFail();
			this->printDealerCardsLast();


		}

	}
}
void Table::updateMoney()
{
	int max = 0;
	int r = this->getDealer().getSumOfCardsAce();
	int n = this->getDealer().getSumOfCards();
	bool aceDealer = this->getDealer().getCard1() == 1;
	bool blackJackDealer = this->getDealer().getSumOfCardsAce() == 21;

	max = maxFunc(r, n);

	for (int i = 0;i < 4;i++)
	{

		if (this->getPointerTable(i) != NULL)
		{
			if (aceDealer && blackJackDealer)
			{
				if (this->getIndexInTable(i).getInsuranceChoice())
				{

					this->getIndexInTable(i).setMoneyInsurance(2);
				}
			}
			else
			{
				if (this->getIndexInTable(i).getInsuranceChoice())
				{

					this->getIndexInTable(i).setMoneyInsurance(-1);
				}

			}

			for (int k = 0;k < 2;k++)
			{
				if (this->getIndexInTable(i).getHand(k) != NULL)
				{

					this->getIndexInTable(i).getHand(k)->setWin(max, getDealer().getNumOfMoreCards());
					this->getIndexInTable(i).getHand(k)->setDrow(max, getDealer().getNumOfMoreCards());

				}

			}
			this->getIndexInTable(i).calculateMoney();
		}
	}
}
void Table::printBoard()
{
	this->printTable();
}
void Table::removePlayer(int i)
{
	this->_players[i] = NULL;
}
void Table::startGame()
{
	printBoard();
	runGame();
	updateMoney();
	for (int i = 0;i < 4;i++)
		if (this->getPointerTable(i) != NULL) {
			this->getIndexInTable(i).printPlayer(true);
		}
	cout << "Hope you enjoy " << endl;
}
Table::Table(int money)
{
	this->_minMoney = money;
	for (int i = 0;i < 4;i++)
	{
		this->_players[i] = NULL;
	}
}
