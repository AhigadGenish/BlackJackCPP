#include "Game.h"
#include "Sql.h"


void menu()
{
	int startChoice = 0;
	cout << " ******************************* " << endl;
	cout << "Welcome to the casino - BlackJack!" << endl;
	cout << " ******************************* " << endl;
	cout << "for play press 1, exit press 0" << endl;
	cin >> startChoice;
	if (!startChoice)
	{
		cout << "GoodBye" << endl;
		return;
	}
	else
		gameFunc();
}

void gameFunc() {

	int minBet = 500;
	int validPlayers = 0, subChoice = 0, setting = 0, sortChoice = 0;
	int seats[4] = {};
	int id[4] = {};
	int decision = -1, num = -1;
	int noValid = 0;
	string userName[4] = {};
	string str0 = {};
	string password = {};

	while (decision){

		if (num == -1)
			num++;
		validPlayers = 0;
		cout << "logIn press 1 ,new user press 2 ,start play press 3, settings/logOut press 4, exit 0" << endl;
		cin >> decision;
		switch (decision)
		{

		case 1: {
			try {
				bool login = false;
				sql::Driver* driver;
				sql::Connection* con;
				sql::PreparedStatement* prep_stmt;


				/* Create a connection */
				driver = get_driver_instance();
				con = driver->connect("tcp://127.0.0.1:3306", "root", "12345678");
				/* Connect to the MySQL test database */
				con->setSchema("bjusers");
				for (int i = 0;i < 3;i++)
				{
					for (int j = 0; j < 3 - i;j++)
						if (userName[j].size() <= userName[j + 1].size())
						{
							string temp = userName[j];
							userName[j] = userName[j + 1];
							userName[j + 1] = temp;
						}
				}
				if (num < 4){
					cout << "please insert userName" << endl;
					cin >> str0;
					for (int j = 0;j < 4;j++)
						if (str0 == userName[j]){
						
							cout << "you already log in" << endl;
							login = true;
							break;
						}
					if (login)
						break;
				
					for (int i = 0;i < 4;i++)
					{
						if ((userName[i]).size() == 0)
						{
							userName[i] = str0;
							cout << "please insert password" << endl;
							cin >> password;
							if (logIn(con, userName[i], password))
								num++;
							else {
								userName[i] = {};
								password = {};
							}
							break;
						}
					}
				}
				else
					cout << "Table is full" << endl;
				delete con;
			}
			catch (sql::SQLException& e) {
				cout << "# ERR: SQLException in " << endl;
				cout << "(" << endl << ") on line " << endl;
				cout << "# ERR: " << e.what();
				cout << " (MySQL error code: " << e.getErrorCode();
				cout << ", SQLState: " << e.getSQLState() << " )" << endl;
			}
		}
			  break;
		case 2:
		{
			try {
				sql::Driver* driver;
				sql::Connection* con;
				sql::PreparedStatement* prep_stmt;


				/* Create a connection */
				driver = get_driver_instance();
				con = driver->connect("tcp://127.0.0.1:3306", "root", "12345678");
				/* Connect to the MySQL test database */
				con->setSchema("bjusers");
				addUser(con);
				delete con;
			}
			catch (sql::SQLException& e) {
				cout << "# ERR: SQLException in " << endl;
				cout << "(" << endl << ") on line " << endl;
				cout << "# ERR: " << e.what();
				cout << " (MySQL error code: " << e.getErrorCode();
				cout << ", SQLState: " << e.getSQLState() << " )" << endl;
			}
		}
		break;
		case 3:
		{
			if (num == 0)
			{
				cout << "empty table , please log in" << endl;
				break;
			}
			try {

				noValid = 0;

				sql::Driver* driver;
				sql::Connection* con;
				sql::PreparedStatement* prep_stmt;

				/* Create a connection */
				driver = get_driver_instance();
				con = driver->connect("tcp://127.0.0.1:3306", "root", "12345678");
				/* Connect to the MySQL test database */
				con->setSchema("bjusers");

				for (int i = 0;i < 3;i++)
				{
					for (int j = 0; j < 3 - i;j++)
						if (userName[j].size() <= userName[j + 1].size())
						{
							string temp = userName[j];
							userName[j] = userName[j + 1];
							userName[j + 1] = temp;
						}
				}

				cout << "which table - minimun bet? (500$,1000$,2000$,5000$)" << endl;
				cin >> minBet;
				while (!(minBet == 500 || minBet == 1000 || minBet == 2000 || minBet == 5000)) {
					cout << "please insert valid number (500$,1000$,2000$,5000$)" << endl;
					cin >> minBet;
				}
				for (int i = 0;i < num;i++)
				{
					
					if (!checkMoney(con, userName[i], minBet)) {
						cout << "please update money " << userName[i] << "(settings)" << endl;
						cout << userName[i] << " log out" << endl;
						noValid += 1;
						userName[i] = {};
					}
					else {
						validPlayers++;
					}
				}
				num -= noValid;
				delete con;
				break;
			}
			catch (sql::SQLException& e) {
				cout << "# ERR: SQLException in " << endl;
				cout << "(" << endl << ") on line " << endl;
				cout << "# ERR: " << e.what();
				cout << " (MySQL error code: " << e.getErrorCode();
				cout << ", SQLState: " << e.getSQLState() << " )" << endl;
			}
		}
		break;
		case 4:
		{	try {
			sql::Driver* driver;
			sql::Connection* con;
			sql::PreparedStatement* prep_stmt;


			/* Create a connection */
			driver = get_driver_instance();
			con = driver->connect("tcp://127.0.0.1:3306", "root", "12345678");
			/* Connect to the MySQL test database */
			con->setSchema("bjusers");

			cout << "for logOut press 1, for settings press 2" << endl;
			cin >> subChoice;
			switch (subChoice)
			{
			case 1: {
				bool exist = false;
				cout << "insert user name please :" << endl;
				cin >> str0;
				for (int i = 0;i < num;i++)
					if (str0 == userName[i])
					{
						exist = true;
						cout << "logOut succesfully" << endl;
						break;
					}
				if (exist == false) {
					cout << " you have to log in first please" << endl;
					break;
				}
				for (int i = 0;i < num;i++)
					if (str0 == userName[i])
					{
						userName[i] = {};
						break;
					}
				num -= 1;
				break;
			}
			case 2: {
				cout << "Setting: for change userName press 1, password 2, playerName 3,update money 4, show table 5, delete user 6, menu 0" << endl;
				cin >> setting;
				switch (setting)
				{
				case 1: {
					bool flag = false;
					int id = -1;
					int i = 0;
					cout << "enter current userName please" << endl;
					cin >> str0;
					id = getId(con, str0);
					if (id != -1)
					{
						for (i = 0;i < num;i++)
							if (str0 == userName[i])
							{
								flag = true;
								break;
							}
						if (!flag)
						{
							cout << "to change username please log in" << endl;
							break;
						}
						userName[i] = changeUserName(con, id);
					}
					else
						cout << "this userName not exist" << endl;
					break;
				}
				case 2: {
					bool flag = false;
					int id = -1;
					cout << "enter userName please" << endl;
					cin >> str0;
					id = getId(con, str0);
					if (id != -1)
					{
						changePassword(con, id);
					}
					else
						cout << "this userName not exist" << endl;
				}

					  break;
				case 3: {
					bool flag = false;
					int id = -1;
					cout << "enter user name please" << endl;
					cin >> str0;
					id = getId(con, str0);
					if (id != -1)
					{
						changePlayerName(con, id);
						cout << "playrName changed" << endl;
					}
					else
						cout << "this userName not exist" << endl;
					break;
				}
				case 4: {
					bool flag = false;
					int id = -1;
					int money = 0;
					cout << "enter userName please" << endl;
					cin >> str0;
					id = getId(con, str0);

					if (id != -1)
					{
						cout << "enter password please" << endl;
						cin >> password;
						if (checkPassword(con, password, id)) {

							cout << "please enter money you want to add" << endl;
							cin >> money;
							while (money < 0) {
								cout << "please enter money you want to add (positive number please)" << endl;
								cin >> money;
							}
							updateTotalMoney(con, id, money);
							cout << "money added" << endl;
						}
						else
							cout << "this is not your password , try again" << endl;
					}
					else
						cout << "this userName not exist" << endl;

					break;
				}
				case 5: {
					cout << "sort table by : 1 profit , 2 numOfWins ,3 No sort" << endl;
					cin >> sortChoice;
					while (!(sortChoice == 1 || sortChoice == 2 || sortChoice == 3))
					{
						cout << "enter valid number please" << endl;
						cin >> sortChoice;
					}
					sortPrint(con, sortChoice);

					break;
				case 6: {
					int answer = 0;
					bool flag = false;
					bool userConnected = false;
					int id = -1;
					cout << "are you sure you want delete? press 1 if yes,else 0" << endl;
					cin >> answer;
					if (!answer)
						break;
					cout << "insert user name please :" << endl;
					cin >> str0;
					id = getId(con, str0);

					if (id != -1)
					{
						cout << "enter password please" << endl;
						cin >> password;
						if (checkPassword(con, password, id)) {
							flag = true;
						}
						else
							cout << "this is not your password , try again" << endl;
					}
					else
						cout << "this userName not exist" << endl;
					if (flag) {
						for (int i = 0;i < num;i++)
							if (str0 == userName[i])
							{
								userConnected = true;
								userName[i] = {};
								break;
							}
						deleteUser(con, id);
						cout << str0 << "is removed" << endl;
						if(userConnected)
							num -= 1;
					}
				}
					break;

				default:
					break;
				}
				}
			}
			default:
				break;
			}
		}

		catch (sql::SQLException& e) {
			cout << "# ERR: SQLException in " << endl;
			cout << "(" << endl << ") on line " << endl;
			cout << "# ERR: " << e.what();
			cout << " (MySQL error code: " << e.getErrorCode();
			cout << ", SQLState: " << e.getSQLState() << " )" << endl;
		}
		break;
		default:

			try {
				sql::Driver* driver;
				sql::Connection* con;
				sql::PreparedStatement* prep_stmt;


				/* Create a connection */
				driver = get_driver_instance();
				con = driver->connect("tcp://127.0.0.1:3306", "root", "12345678");
				/* Connect to the MySQL test database */
				con->setSchema("bjusers");
				printAllPlayers(con);
				delete con;
			}
			catch (sql::SQLException& e) {
				cout << "# ERR: SQLException in " << endl;
				cout << "(" << endl << ") on line " << endl;
				cout << "# ERR: " << e.what();
				cout << " (MySQL error code: " << e.getErrorCode();
				cout << ", SQLState: " << e.getSQLState() << " )" << endl;

			}
			cout << "Goodbye" << endl;
			return;
		}
		}

		try {
			sql::Driver* driver;
			sql::Connection* con;
			sql::PreparedStatement* prep_stmt;


			/* Create a connection */
			driver = get_driver_instance();
			con = driver->connect("tcp://127.0.0.1:3306", "root", "12345678");
			/* Connect to the MySQL test database */
			con->setSchema("bjusers");

			for (int i = 0;i < 3;i++)
			{
				for (int j = 0; j < 3 - i;j++)
					if (userName[j].size() <= userName[j + 1].size())
					{
						string temp = userName[j];
						userName[j] = userName[j + 1];
						userName[j + 1] = temp;
					}
			}

			for (int i = 0;i < validPlayers;i++)
			{
				id[i] = getId(con, userName[i]);
			}
			if (decision == 3) {
			
				switch (validPlayers)
				{
				case 1:
				{
					int sum0 = 0;
					int t = 1;
					while (t)
					{

						Player anyPlayer0(minBet, userName[0], getTotalMoney(con, id[0]), id[0]);
						Table B(minBet);
						B.setTable(anyPlayer0, 0);
						cout << "Let's Play!" << endl;
						B.startGame();
						sum0 = 0;
						if (anyPlayer0.getHand(0) != NULL)
							sum0 = anyPlayer0.getHand(0)->getProfit();
						updateTotalMoney(con, id[0], sum0);
						updateProfit(con, id[0], sum0);

						if (getTotalMoney(con, id[0]) < minBet)
						{
							cout << "no enough money for " << userName[0] << endl;
							B.removePlayer(0);
							break;
						}
						cout << "Another one ?  yes press 1, no 0" << endl;
						cin >> t;
						if (t == 0)
							break;
					}
				}
				break;
				case 2:
				{
					int sum[2] = {};
					int t = 1;
					bool flag[2];
					for (int i = 0;i < validPlayers;i++)
						flag[i] = true;
					cout << userName[0] << " please choose a seat (1-4)" << endl;
					cin >> seats[0];
					while (!(seats[0] == 1 || seats[0] == 2 || seats[0] == 3 || seats[0] == 4))
					{
						cout << "please insert valid number (1-4)" << endl;
						cin >> seats[0];
					}

					cout << userName[1] << " please choose a seat (1-4)" << endl;
					cin >> seats[1];
					while (seats[1] == seats[0] || !(seats[1] == 1 || seats[1] == 2 || seats[1] == 3 || seats[1] == 4))
					{
						cout << "this seat is occupied/ invalid , choose another except " << seats[0] << endl;
						cin >> seats[1];
					}

					while (t)
					{
						Player anyPlayer[2] = { Player(minBet, userName[0], getTotalMoney(con, id[0]),id[0]), Player(minBet, userName[1], getTotalMoney(con, id[1]),id[1]) };
						Table B(minBet);

						for (int i = 0;i < validPlayers;i++)
							if (flag[i])
								B.setTable(anyPlayer[i], (seats[i] - 1));


						cout << "Let's Play!" << endl;
						B.startGame();
						for (int i = 0;i < validPlayers; i++)
							sum[i] = 0;
						for (int i = 0;i < validPlayers;i++)
							if (anyPlayer[i].getHand(0) != NULL)
								sum[i] = anyPlayer[i].getHand(0)->getProfit();

						for (int i = 0;i < validPlayers; i++)
							updateTotalMoney(con, id[i], sum[i]);

						for (int i = 0;i < validPlayers; i++)
							updateProfit(con, id[i], sum[i]);
					

						for (int i = 0;i < validPlayers;i++)
						{
							if (getTotalMoney(con, id[i]) < minBet)
							{
								cout << "no enough money for " << userName[i] << endl;
								flag[i] = false;
								B.removePlayer(seats[i] - 1);

							}
						}

						if (!flag[0] && !flag[1])
							break;
						cout << "Another one ? yes press 1, no 0" << endl;
						cin >> t;
						if (t == 0)
							break;
					}
				}
				break;
				case 3:
				{
					int sum[3] = {};
					int t = 1;
					bool flag[3];
					for (int i = 0;i < 3;i++)
						flag[i] = true;

					cout << userName[0] << " please choose a seat (1-4)" << endl;
					cin >> seats[0];
					while (!(seats[0] == 1 || seats[0] == 2 || seats[0] == 3 || seats[0] == 4))
					{
						cout << "please insert valid number (1-4)" << endl;
						cin >> seats[0];
					}

					cout << userName[1] << " please choose a seat (1-4)" << endl;
					cin >> seats[1];
					while (seats[1] == seats[0] || !(seats[1] == 1 || seats[1] == 2 || seats[1] == 3 || seats[1] == 4))
					{
						cout << "this seat is occupied/ invalid , choose another except " << seats[0] << endl;
						cin >> seats[1];
					}

					cout << userName[2] << " please choose a seat (1-4)" << endl;
					cin >> seats[2];
					while (seats[2] == seats[1] || seats[2] == seats[0] || !(seats[2] == 1 || seats[2] == 2 || seats[2] == 3 || seats[2] == 4))
					{
						cout << "this seat is occupied/ invalid , choose another except " << seats[1] << seats[0] << endl;
						cin >> seats[2];
					}
					while (t)
					{
						Player anyPlayer[3] = { Player(minBet, userName[0], getTotalMoney(con, id[0]),id[0]), Player(minBet, userName[1], getTotalMoney(con, id[1]),id[1]),
						Player(minBet, userName[2], getTotalMoney(con, id[2]),id[2]) };
						Table B(minBet);

						for (int i = 0;i < validPlayers;i++)
							if (flag[i])
								B.setTable(anyPlayer[i], (seats[i] - 1));


						cout << "Let's Play!" << endl;
						B.startGame();
						for (int i = 0;i < validPlayers; i++)
							sum[i] = 0;
						for (int i = 0;i < validPlayers;i++)
							if (anyPlayer[i].getHand(0) != NULL)
								sum[i] = anyPlayer[i].getHand(0)->getProfit();

						for (int i = 0;i < validPlayers; i++)
							updateTotalMoney(con, id[i], sum[i]);
						for (int i = 0;i < validPlayers; i++)
							updateProfit(con, id[i], sum[i]);


						for (int i = 0;i < validPlayers;i++)
						{
							if (getTotalMoney(con, id[i]) < minBet)
							{
								cout << "no enough money for " << userName[i] << endl;
								flag[i] = false;
								B.removePlayer(seats[i] - 1);

							}
						}

						if (!flag[0] && !flag[1] && !flag[2])
							break;
						cout << "Another one ? yes press 1, no 0" << endl;
						cin >> t;
						if (t == 0)
							break;
					}
				}
				break;
				case 4:
				{
					int sum[4] = {};
					int t = 1;
					bool flag[4];
					for (int i = 0;i < 4;i++)
						flag[i] = true;

					cout << userName[0] << " please choose a seat (1-4)" << endl;
					cin >> seats[0];
					while (!(seats[0] == 1 || seats[0] == 2 || seats[0] == 3 || seats[0] == 4))
					{
						cout << "please insert valid number (1-4)" << endl;
						cin >> seats[0];
					}

					cout << userName[1] << " please choose a seat (1-4)" << endl;
					cin >> seats[1];
					while (seats[1] == seats[0] || !(seats[1] == 1 || seats[1] == 2 || seats[1] == 3 || seats[1] == 4))
					{
						cout << "this seat is occupied/ invalid , choose another except " << seats[0] << endl;
						cin >> seats[1];
					}

					cout << userName[2] << " please choose a seat (1-4)" << endl;
					cin >> seats[2];
					while (seats[2] == seats[1] || seats[2] == seats[0] || !(seats[2] == 1 || seats[2] == 2 || seats[2] == 3 || seats[2] == 4))
					{
						cout << "this seat is occupied/ invalid , choose another except " << seats[1] << seats[0] << endl;
						cin >> seats[2];
					}
					for (int i = 1;i < 5;i++)
					{
						if (!(i == seats[0] || i == seats[1] || i == seats[2]))
							seats[3] = i;
					}
					while (t)
					{
						Player anyPlayer[4] = { Player(minBet, userName[0], getTotalMoney(con, id[0]),id[0]), Player(minBet, userName[1], getTotalMoney(con, id[1]),id[1]),
							Player(minBet, userName[2], getTotalMoney(con, id[2]),id[2]), Player(minBet, userName[3], getTotalMoney(con, id[3]),id[3]) };
						Table B(minBet);

						for (int i = 0;i < validPlayers;i++)
							if (flag[i])
								B.setTable(anyPlayer[i], (seats[i] - 1));


						cout << "Let's Play!" << endl;
						B.startGame();
						for (int i = 0;i < validPlayers; i++)
							sum[i] = 0;
						for (int i = 0;i < validPlayers;i++)
							if (anyPlayer[i].getHand(0) != NULL)
								sum[i] = anyPlayer[i].getHand(0)->getProfit();

						for (int i = 0;i < validPlayers; i++)
							updateTotalMoney(con, id[i], sum[i]);
						for (int i = 0;i < validPlayers; i++)
							updateProfit(con, id[i], sum[i]);


						for (int i = 0;i < validPlayers;i++)
						{
							if (getTotalMoney(con, id[i]) < minBet)
							{
								cout << "no enough money for " << userName[i] << endl;
								flag[i] = false;
								B.removePlayer(seats[i] - 1);

							}
						}

						if (!flag[0] && !flag[1] && !flag[2] && !flag[3])
							break;
						cout << "Another one ? yes press 1, no 0" << endl;
						cin >> t;
						if (t == 0)
							break;
					}
				}
				break;


				default:

					break;
				}
			}

			delete con;

		}
		catch (sql::SQLException& e) {
			cout << "# ERR: SQLException in " << endl;
			cout << "(" << endl << ") on line " << endl;
			cout << "# ERR: " << e.what();
			cout << " (MySQL error code: " << e.getErrorCode();
			cout << ", SQLState: " << e.getSQLState() << " )" << endl;
		}
	}
	cout << "GoodBye" << endl;
	return;
}
