#include <stdlib.h>

/*
  Include directly the different
  headers from cppconn/ and mysql_driver.h + mysql_util.h
  (and mysql_connection.h). This will reduce your build time!
*/
#include "mysql_connection.h"
#include <cppconn/driver.h>
#include <cppconn/exception.h>
#include <cppconn/resultset.h>
#include <cppconn/statement.h>
#include <cppconn/prepared_statement.h>


using namespace std;
// add user
void addUser(sql::Connection* con);
// print the table
void printAllPlayers(sql::Connection* con);
// settings
string changeUserName(sql::Connection* con, int id);
void changePlayerName(sql::Connection* con,  int id);
void changePassword(sql::Connection* con,  int id);
void updateTotalMoney(sql::Connection* con,  int id ,int cash);
bool logIn(sql::Connection* con, string userName, string password);
void updateProfit(sql::Connection* con, int id, int profit);
void updateNumOfGames(sql::Connection* con, int id);
void updateNumOfWin(sql::Connection* con, int id);
void updateNumOfLose(sql::Connection* con, int id);
void updateNumOfTie(sql::Connection* con, int id);
void deleteUser(sql::Connection* con, int id);
bool checkMoney(sql::Connection* con, string userName, int min);

// getters
int getId(sql::Connection* con, string userName);
int getTotalMoney(sql::Connection* con, int id);
int getNumOfGames(sql::Connection* con, int id);
int getNumOfWin(sql::Connection* con, int id);
int getNumOfTie(sql::Connection* con, int id);
int getNumOfLose(sql::Connection* con, int id);
int getProfit(sql::Connection* con, int id);
string getUserName(sql::Connection* con, int id);
// sort the table and print
void sortPrint(sql::Connection* con, int choice);
int sizeOfTable(sql::Connection* con);
void sortTable(int** arr, int n);
void printId(sql::Connection* con, int id);
void swapElements(int* a, int* b);
bool checkPassword(sql::Connection* con, string password, int id);
bool checkUserName(sql::Connection* con, string userName);