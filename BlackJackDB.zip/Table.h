#include "Player.h"
class Table
{
private:

	Hand _dealerHand;
	Player* _players[4];
	bool _anyPlayer;
	int _minMoney;

public:
	//getters.
	Hand& getDealer()
	{
		return this->_dealerHand;
	}

	Player& getIndexInTable(int i) const
	{
		return *this->_players[i];
	}
	Player* getPointerTable(int i) const
	{
		return this->_players[i];
	}
	bool getDealerFail() const
	{
		return this->_dealerHand.getFail();
	}
	int getSumOfDealerCards() const
	{
		return this->_dealerHand.getSumOfCards();
	}
	int getSumOfDealerCardsAce() const
	{
		return this->_dealerHand.getSumOfCardsAce();
	}
	//remove player from table.
	void removePlayer(int i);
	//print table.
	void printTable() const;
	//print dealer cards.
	void printDealerCardsFirst() const;
	void printDealerCardsLast() const;
	//insert players.
	void setTable(Player& A, int chair);
	//update money for players.
	void updateMoney();
	// game function
	void setGame();
	// game function
	void runGame();
	// game function
	void startGame();
	//setTurn to next hand.
	void setHandTurn(int i, int k);
	//setTurn to dealer.
	void switchTurn();
	//print board.
	void printBoard();
	//replace the dealer cards.
	bool setDealerCards();
	//check for insurance.
	bool setInsurance(int card);
	//take the max if has any ace.
	int maxFunc(int n, int r);
	//constructor.
	Table(int minMoney = 500);



};


