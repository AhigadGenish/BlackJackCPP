#include "Sql.h"


void swapElements(int* a, int* b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}
void addUser(sql::Connection* con) {

	sql::PreparedStatement* prep_stmt;
	sql::ResultSet* res;
	sql::Statement* stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");
	string  playerName, userName, password;
	int totalMoney;

	cout << "Enter name:" << endl;
	cin >> playerName;
	cout << "Enter user name:" << endl;
	cin >> userName;
	while (res->next())
	{
		if (userName == res->getString(2))
		{
			cout << "This userName is occupied, please insert another userName" << endl;
			cin >> userName;
			res = stmt->executeQuery("SELECT * FROM Users");
		}
	}
	cout << "Enter password" << endl;
	cin >> password;
	cout << "Enter amount of cash: $" << endl;
	cin >> totalMoney;
	prep_stmt = con->prepareStatement("insert into Users (username,passoword, playerName,totalMoney,profit,numOfGames,NumOfWin,numOfTie,numOfLose) values (?,?,?,?,?,?,?,?,?)");
	prep_stmt->setString(1, userName);
	prep_stmt->setString(2, password);
	prep_stmt->setString(3, playerName);
	prep_stmt->setInt(4, totalMoney);
	prep_stmt->setInt(5, 0);
	prep_stmt->setInt(6, 0);
	prep_stmt->setInt(7, 0);
	prep_stmt->setInt(8, 0);
	prep_stmt->setInt(9, 0);

	prep_stmt->execute();
	cout << "added user: " << userName << endl;
	delete prep_stmt;

}

void printAllPlayers(sql::Connection* con) {

	sql::Statement* stmt;
	sql::ResultSet* res;
	stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");
	while (res->next()) {
		// You can use either numeric offsets...

		cout << " id = " << res->getInt(1);// getInt(1) returns the first column
		cout << " userName = " << res->getString(2); // getInt(2) returns the first column // getInt(2) returns the first column
		cout << " totalMoney = " << res->getString(5);
		cout << " profit = " << res->getString(6);
		cout << " numOfGames = " << res->getString(7);
		cout << " numOfWins = " << res->getString(8);
		cout << " numOfTie = " << res->getString(9);
		cout << " numOfLose = " << res->getString(10) << endl;
		cout << " *********************** " << endl;


	}
	delete stmt;
	delete res;
}
bool logIn(sql::Connection* con, string userName, string password)
{
	bool flagUserName = false;
	bool flagPassword = false;
	flagUserName = checkUserName(con, userName);
	if (!flagUserName)
	{
		cout << "user not exist" << endl;
		cout << "please try log in again" << endl;
		return false;
	}
	flagPassword = checkPassword(con, password, getId(con, userName));
	if (!flagPassword) {
		cout << "wrong password (change if you forgot [settings])" << endl;
		cout << "please try log in again" << endl;
		return false;
	}
	
	cout << "Log in succesfully" << endl;
		return true;



}
bool checkUserName(sql::Connection* con, string userName) {
	sql::PreparedStatement* pstmt;
	sql::ResultSet* res;
	sql::Statement* stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");

	while (res->next())
	{
		if (userName == res->getString(2))
			return true;
	}
	return false;
}
bool checkPassword(sql::Connection* con, string password, int id) {

	sql::PreparedStatement* pstmt;
	sql::ResultSet* res;
	sql::Statement* stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");

	while (res->next())
	{
		if (res->getInt(1) == id)
		{
			if(password == res->getString(3))
				return true;
		}
	}
	return false;
}
int getTotalMoney(sql::Connection* con, int id)
{
	int totalMoney = 0;
	sql::PreparedStatement* pstmt;
	sql::ResultSet* res;
	sql::Statement* stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");

	while (res->next())
	{
		if (res->getInt(1) == id)
		{
			totalMoney = res->getInt(5);
			break;
		

		}
	}
	delete res;
	return totalMoney;
	
}
int getProfit(sql::Connection* con, int id)
{
	int profit = 0;
	sql::PreparedStatement* pstmt;
	sql::ResultSet* res;
	sql::Statement* stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");

	while (res->next())
	{
		if (res->getInt(1) == id)
		{
			profit = res->getInt(6);


		}
	}
	delete res;
	return profit;
}
void updateTotalMoney(sql::Connection* con, int id, int cash) {

	int totalMoney = getTotalMoney(con, id);
	totalMoney += cash;
	sql::PreparedStatement* pstmt;
	pstmt = con->prepareStatement("UPDATE Users SET totalMoney = ? WHERE id = ?");
	pstmt->setInt(1, totalMoney);
	pstmt->setInt(2, id);
	pstmt->executeQuery();
	delete pstmt;
}
void updateProfit(sql::Connection* con, int id, int profit) {

	int newProfit = getProfit(con,id);
	newProfit += profit;
	sql::PreparedStatement* pstmt;
	pstmt = con->prepareStatement("UPDATE Users SET profit = ? WHERE id = ?");
	pstmt->setInt(1, newProfit);
	pstmt->setInt(2, id);
	pstmt->executeQuery();
	delete pstmt;
}
void updateNumOfGames(sql::Connection* con, int id) {

	int numOfGames = getNumOfGames(con,id);
	numOfGames += 1;
	sql::PreparedStatement* pstmt;
	pstmt = con->prepareStatement("UPDATE Users SET NumOfGames = ? WHERE id = ?");
	pstmt->setInt(1, numOfGames);
	pstmt->setInt(2, id);
	pstmt->executeQuery();
	delete pstmt;

}
void updateNumOfWin(sql::Connection* con, int id) {
	int numOfWins = getNumOfWin(con, id);
	numOfWins += 1;
	sql::PreparedStatement* pstmt;
	pstmt = con->prepareStatement("UPDATE Users SET numOfWin = ? WHERE id = ?");
	pstmt->setInt(1, numOfWins);
	pstmt->setInt(2, id);
	pstmt->executeQuery();
	delete pstmt;

}
void updateNumOfLose(sql::Connection* con, int id) {
	int numOfLose = getNumOfLose(con, id);
	numOfLose += 1;
	sql::PreparedStatement* pstmt;
	pstmt = con->prepareStatement("UPDATE Users SET numOfLose = ? WHERE id = ?");
	pstmt->setInt(1, numOfLose);
	pstmt->setInt(2, id);
	pstmt->executeQuery();
	delete pstmt;

}
void updateNumOfTie(sql::Connection* con, int id) {
	int numOfTie = getNumOfTie(con, id);
	numOfTie += 1;
	sql::PreparedStatement* pstmt;
	pstmt = con->prepareStatement("UPDATE Users SET numOfTie = ? WHERE id = ?");
	pstmt->setInt(1, numOfTie);
	pstmt->setInt(2, id);
	pstmt->executeQuery();
	delete pstmt;

}
void deleteUser(sql::Connection* con, int id) {

	sql::PreparedStatement* pstmt;
	pstmt = con->prepareStatement("DELETE FROM Users WHERE id = ?");
	pstmt->setInt(1, id);
	pstmt->executeQuery();
	delete pstmt;
}
bool checkMoney(sql::Connection* con, string userName, int min)
{
	bool check = false;
	sql::Statement* stmt;
	sql::ResultSet* res;
	stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");
	

	while (res->next()) {
		// You can use either numeric offsets...

	
		if (userName == res->getString(2))
		{
			if (res->getInt(5) >= min)
			{
				check = true;
				break;
			}


		
		}

	}
	delete res;
	return check;
}
int getId(sql::Connection* con, string userName)
{
	int id = -1;
	sql::Statement* stmt;
	sql::ResultSet* res;
	stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");
	while (res->next()) {
		


		if (userName == res->getString(2))
		{
			id = res->getInt(1);
			break;
			
		}


	}
	delete res;
	return id;
}
int getNumOfGames(sql::Connection* con, int id) {

	int games = 0;
	sql::PreparedStatement* pstmt;
	sql::ResultSet* res;
	sql::Statement* stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");

	while (res->next())
	{
		if (res->getInt(1) == id)
		{
			games =  res->getInt(7);
			break;


		}
	}
	delete res;
	return games;
}
int getNumOfWin(sql::Connection* con, int id) {

	int win = -1;
	sql::ResultSet* res;
	sql::Statement* stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");

	while (res->next())
	{
		if (res->getInt(1) == id)
		{
			win = res->getInt(8);
			break;

		}
	}
	delete res;
	if (win == -1)
		cout << "no exist such username" << endl;
	return win;
}
int getNumOfTie(sql::Connection* con, int id) {
	
	int tie = -1;
	sql::ResultSet* res;
	sql::Statement* stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");

	while (res->next())
	{
		if (res->getInt(1) == id)
		{
			tie = res->getInt(9);
			break;

		}
	}
	delete res;
	if (tie == -1)
		cout << "no exist such username" << endl;
	return tie;
}
int getNumOfLose(sql::Connection* con, int id) {

	int lose = -1;
	sql::ResultSet* res;
	sql::Statement* stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");

	while (res->next())
	{
		if (res->getInt(1) == id)
		{
			lose = res->getInt(10);
			break;

		}
	}
	delete res;
	if (lose == -1)
		cout << "no exist such username" << endl;
	return lose;

}
string changeUserName(sql::Connection* con,  int id)
{
	string userName;
	sql::PreparedStatement* prep_stmt;
	sql::ResultSet* res;
	sql::PreparedStatement* pstmt;
	sql::Statement* stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");
	cout << "Enter new userName:" << endl;
	cin >> userName;
	if (getUserName(con, id) == userName)
		return userName;
	while (res->next())
	{
		if (userName == res->getString(2))
		{
			cout << "This userName is occupied, please insert another userName" << endl;
			cin >> userName;
			res = stmt->executeQuery("SELECT * FROM Users");
		}
	}
	
	pstmt = con->prepareStatement("UPDATE Users SET userName = ? WHERE id = ?");
	pstmt->setString(1, userName);
	pstmt->setInt(2, id);
	pstmt->executeQuery();
	cout << "userName changed" << endl;
	delete pstmt;
	delete res;
	return userName;

}
string getUserName(sql::Connection* con, int id) {

	string userName = "anyUser";
	sql::ResultSet* res;
	sql::Statement* stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");
	while (res->next())
	{
		if (id == res->getInt(1))
		{
			userName =  res->getString(2);
			break;
		}
	}
	
	delete res;
	return userName;
}
void changePlayerName(sql::Connection* con,  int id)
{
	string oldPlayerName, newPlayerName;
	bool flag = false;
	sql::PreparedStatement* prep_stmt;
	sql::ResultSet* res;
	sql::Statement* stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");
	cout << "Enter old PlayerName:" << endl;
	cin >> oldPlayerName;
	while (res->next())
	{
		if (res->getInt(1) == id)
		{
			if (oldPlayerName == res->getString(4))
				flag = true;
		}
	}
	if (flag) {
		cout << "Enter new playerName:" << endl;
		cin >> newPlayerName;
		sql::PreparedStatement* pstmt;
		pstmt = con->prepareStatement("UPDATE Users SET playerName = ? WHERE id = ?");
		pstmt->setString(1, newPlayerName);
		pstmt->setInt(2, id);
		pstmt->executeQuery();
		delete pstmt;
	}
	else
		cout << "this is not your name " << endl;
	delete res;
}
void changePassword(sql::Connection* con, int id)
{
	bool flag = false;
	bool nameFlag = false;
	int choice;
	string oldPassword, newPassword, name;
	sql::PreparedStatement* prep_stmt;
	sql::ResultSet* res;
	sql::Statement* stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");
	cout << "Enter old password:" << endl;
	cin >> oldPassword;
	while (res->next())
	{
		if (res->getInt(1) == id)
		{
			if (oldPassword == res->getString(3))
			{
				flag = true;
				break;
			}

			

		}
	}

	while (!flag)
	{
		cout << "wrong password, forgot your password? for yes press 1 , else press 2" << endl;
		cin >> choice;
		switch (choice)
		{
		case 1:
		{
			cout << "please enter your name" << endl;
			cin >> name;
			res = stmt->executeQuery("SELECT * FROM Users");
			while (res->next())
			{
				if (res->getInt(1) == id)
				{
					if (name == res->getString(4))
						nameFlag = true;
				}
			}
			if (!nameFlag)
				cout << "this is not your name, can't change password" << endl;
			else
				break;
		}


		break;
		case 2:
		{
			changePassword(con, id);
		}
			break;
		default:
			break;
		}
		 
	


	}

	if (nameFlag || flag) {
		cout << "Enter new password:" << endl;
		cin >> newPassword;
		sql::PreparedStatement* pstmt;
		pstmt = con->prepareStatement("UPDATE Users SET passoword = ? WHERE id = ?");
		pstmt->setString(1, newPassword);
		pstmt->setInt(2, id);
		pstmt->executeQuery();
		delete pstmt;
		cout << "Password changed " << endl;
	}
	delete res;
	delete stmt;


}
void printId(sql::Connection* con, int id)
{
	sql::ResultSet* res;
	sql::Statement* stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");

	while (res->next())
	{
		if (res->getInt(1) == id)
		{
			cout << " id = " << res->getInt(1);// getInt(1) returns the first column
			cout << " userName = " << res->getString(2); // getInt(2) returns the first column // getInt(2) returns the first column
			cout << " totalMoney = " << res->getString(5);
			cout << " profit = " << res->getString(6);
			cout << " numOfGames = " << res->getString(7);
			cout << " numOfWins = " << res->getString(8);
			cout << " numOfTie = " << res->getString(9);
			cout << " numOfLose = " << res->getString(10) << endl;
			cout << " *********************** " << endl;

			return;
		}
	}
	delete stmt;
	delete res;

}

int sizeOfTable(sql::Connection* con) {
	int size = 0;
	sql::Statement* stmt;
	sql::ResultSet* res;
	stmt = con->createStatement();
	res = stmt->executeQuery("SELECT * FROM Users");
	while (res->next()) {
	
		size += 1;
	}
	delete stmt;
	delete res;
	return size;
}
void sortTable(int** arr, int n)
{

	for (int i = 0;i < n - 1;i++)
		for (int j = 0; j < n - i - 1; j++)
			if (arr[1][j] < arr[1][j + 1]) {
				swapElements(&arr[1][j], &arr[1][j + 1]);
				swapElements(&arr[0][j], &arr[0][j + 1]);
			}
}
void sortPrint(sql::Connection* con, int choice)
{

	switch (choice)
	{
	case 1: {

		int** profit = NULL;
		int col = sizeOfTable(con);
		int row = 2;
		profit = new int*[row];
		for (int i = 0; i < row;i++)
			profit[i] = new int[col];

		sql::Statement* stmt;
		sql::ResultSet* res;
		stmt = con->createStatement();
		res = stmt->executeQuery("SELECT * FROM Users");
		int  i = 0;
		while (res->next()) {
			profit[0][i] = res->getInt(1);
			profit[1][i] = res->getInt(6);
			i += 1;
		}
		sortTable(profit, col);
		cout << " Print sort by profit : " << endl;
		for (int i = 0;i < col;i++)
			printId(con, profit[0][i]);
	
		delete profit;
		delete stmt;
		delete res;
		}
		break;
	case 2: {

		int** wins = NULL;
		int col = sizeOfTable(con);
		int row = 2;
		wins = new int* [row];
		for (int i = 0; i < row;i++)
			wins[i] = new int[col];

		sql::Statement* stmt;
		sql::ResultSet* res;
		stmt = con->createStatement();
		res = stmt->executeQuery("SELECT * FROM Users");
		int  i = 0;
		while (res->next()) {
			wins[0][i] = res->getInt(1);
			wins[1][i] = res->getInt(8);
			i += 1;
		}
		sortTable(wins, col);
		cout << " Print sort by wins : " << endl;
		for (int i = 0;i < col;i++)
			printId(con, wins[0][i]);

		delete wins;
		delete stmt;
		delete res;
	}
	break;
	default:
		printAllPlayers(con);
			return;
	}
}
