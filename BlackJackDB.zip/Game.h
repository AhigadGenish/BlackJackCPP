#include "Table.h"

void gameFunc();
void menu();
