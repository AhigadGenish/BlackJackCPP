#include "Game.h"

//Ahigad Genish
//ahigad.genish@gmail.com

int Player::_numOfPlayers = 0;

int main()
{
	srand(time(0));
	gameFunc();
	return 0;
}