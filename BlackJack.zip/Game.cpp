#include "Game.h"

void gameFunc()
{
	int playChoice = 1;
	cout << " ******************************* " << endl;
	cout << "Welcome to the casino - BlackJack!" << endl;
	cout << " ******************************* " << endl;
	while (playChoice)
	{
		int numOfPlayers = 0, minBet = 0;
		int seats[4];
		string playerName[4] = {};
		cout << "for play press 1,exit press 0" << endl;
		cin >> playChoice;
		if (!playChoice)
		{
			cout << "GoodBye" << endl;
			return;
		}
		cout << "How many players? (1-4)" << endl;
		cin >> numOfPlayers;
		while (numOfPlayers > 4 || numOfPlayers < 0)
		{
			cout << "please insert valid number (1-4)" << endl;
			cin >> numOfPlayers;
		}
		cout << "which table - minimun bet? (500$,1000$,2000$,5000$)" << endl;
		cin >> minBet;
		while (!(minBet == 500 || minBet == 1000 || minBet == 2000 || minBet == 5000)) {
			cout << "please insert valid number (500$,1000$,2000$,5000$)" << endl;
			cin >> minBet;
		}

		
		switch (numOfPlayers)
		{
		case 1:
		{	int money = 0;
			int newMoney = 0;
			int sum0 = 0;
			int decision = 1;
			bool flag = true;
			cout << "Insert Name please" << endl;
			cin >> playerName[0];
			cout << "Insert Total Money please (minimum " << minBet << "$)" << endl;
			cin >> money;
		
			while (money < minBet)
			{
				cout << "minimum " << minBet << endl;
				cin >> money;
			}
			newMoney = money;
			while (decision)
			{
				Player anyPlayer0(minBet, playerName[0], money);
				Table B(minBet);
				B.setTable(anyPlayer0, 0);
				cout << "Let's Play!" << endl;
				B.startGame();
				sum0 = 0;
				if (anyPlayer0.getHand(0) != NULL)
					sum0 = anyPlayer0.getHand(0)->getProfit();
				
				newMoney += sum0;
				if (newMoney < minBet)
				{
					cout << "no enough money for " << anyPlayer0.getName() << endl;
					B.removePlayer(0);
					flag = false;
					break;
				}
				cout << "Another one ?  yes press 1, no 0" << endl;
				cin >> decision;
				if (decision == 0)
					break;
				if (flag)
					money = newMoney;
			

			}
		}
		break;


		case 2:
		{
			int money[2] = {};
			int newMoney[2] = {};
			int sum[2] = {};
			int decision = 1;
			bool flag[2];
			for (int i = 0;i < numOfPlayers;i++)
				flag[i] = true;
			cout << " Player 1 : Insert Name please" << endl;
			cin >> playerName[0];
			cout << "Player 1 : Insert Money please (minimum " << minBet << "$)" << endl;
			cin >> money[0];

			while (money[0] < minBet)
			{
				cout << "minimum " << minBet << endl;
				cin >> money[0];
			}
			cout << "Player 1: choose a seat (1-4)" << endl;
			cin >> seats[0];
			while (!(seats[0] == 1 || seats[0] == 2 || seats[0] == 3 || seats[0] == 4))
			{
				cout << "please insert valid number (1-4)" << endl;
				cin >> seats[0];
			}
			cout << " Player 2 : Insert Name please" << endl;
			cin >> playerName[1];
			cout << "Player 2 : Insert Money please (minimum " << minBet << "$)" << endl;
			cin >> money[1];
			while (money[1] < minBet)
			{
				cout << "minimum " << minBet << endl;
				cin >> money[1];
			}
			cout << "Player 2: choose a seat (1-4)" << endl;
			cin >> seats[1];
			while (seats[0] == seats[1] || !(seats[1] == 1 || seats[1] == 2 || seats[1] == 3 || seats[1] == 4))
			{
				cout << "the seat is occupied/ invalid , choose another except " << seats[0] << endl;
				cin >> seats[1];
			}
			for (int i = 0;i < numOfPlayers;i++)
				newMoney[i] = money[i];
			while (decision)
			{
				Player anyPlayer[2] = { Player(minBet,playerName[0],money[0]),Player(minBet,playerName[1],money[1]) };
				Table B(minBet);

				for (int i = 0;i < numOfPlayers;i++)
					if (flag[i])
						B.setTable(anyPlayer[i], (seats[i] - 1));

				cout << "Let's Play!" << endl;
				B.startGame();
				for (int i = 0;i < numOfPlayers;i++)
					sum[i] = 0;
				for (int i = 0;i < numOfPlayers;i++)
					if (anyPlayer[i].getHand(0) != NULL)
						sum[i] = anyPlayer[i].getHand(0)->getProfit();

			
				for (int i = 0;i < numOfPlayers;i++)
					newMoney[i] += sum[i];

				for (int i = 0;i < numOfPlayers;i++)
					if (newMoney[i] < minBet)
					{
						cout << "no enough money for " << anyPlayer[i].getName() << endl;
						flag[i] = false;
						B.removePlayer(seats[i] - 1);
					}

				if (!flag[0] && !flag[1])
					break;
				cout << "Another one ? yes press 1, no 0" << endl;
				cin >> decision;
				if (decision == 0)
					break;
				for (int i = 0;i < numOfPlayers;i++)
					if (flag[i])
						money[i] = newMoney[i];
			}
		}
		break;

		case 3:
		{
			int money[3] = {};
			int newMoney[3] = {};
			int sum[3] = {};
			int decision = 1;
			bool flag[3];
			for (int i = 0;i < numOfPlayers;i++)
				flag[i] = true;
			cout << " Player 1 : Insert Name please" << endl;
			cin >> playerName[0];
			cout << "Player 1 : Insert Money please (minimum " << minBet << "$)" << endl;
			cin >> money[0];

			while (money[0] < minBet)
			{
				cout << "minimum " << minBet << endl;
				cin >> money[0];
			}
			cout << "Player 1: choose a seat (1-4)" << endl;
			cin >> seats[0];
			while (!(seats[0] == 1 || seats[0] == 2 || seats[0] == 3 || seats[0] == 4))
			{
				cout << "please insert valid number (1-4)" << endl;
				cin >> seats[0];
			}
			cout << " Player 2 : Insert Name please" << endl;
			cin >> playerName[1];
			cout << "Player 2 : Insert Money please (minimum " << minBet << "$)" << endl;
			cin >> money[1];
			while (money[1] < minBet)
			{
				cout << "minimum " << minBet << endl;
				cin >> money[1];
			}
			cout << "Player 2: choose a seat (1-4)" << endl;
			cin >> seats[1];
			while (seats[0] == seats[1] || !(seats[1] == 1 || seats[1] == 2 || seats[1] == 3 || seats[1] == 4))
			{
				cout << "the seat is occupied/ invalid , choose another except " << seats[0] << endl;
				cin >> seats[1];
			}

			cout << " Player 3 : insert Name please" << endl;
			cin >> playerName[2];
			cout << "Player 3 : insert Money please (minimum " << minBet << "$)" << endl;
			cin >> money[2];
			while (money[2] < minBet)
			{
				cout << "minimum " << minBet << endl;
				cin >> money[2];
			}
			cout << "Player 3: choose a seat (1-4)" << endl;
			cin >> seats[2];
			while (seats[1] == seats[2] || seats[0] == seats[2] || !(seats[2] == 1 || seats[2] == 2 || seats[2] == 3 || seats[2] == 4))
			{
				cout << "the seat is occupied / invalid , choose another except " << seats[1] << " " << seats[0] << endl;
				cin >> seats[2];
			}
			for (int i = 0;i < numOfPlayers;i++)
				newMoney[i] = money[i];

			while (decision)
			{
				Player anyPlayer[3] = { Player(minBet,playerName[0],money[0]),Player(minBet,playerName[1],money[1]),
					Player(minBet,playerName[2],money[2]) };
				Table B(minBet);

				for (int i = 0;i < numOfPlayers;i++)
					if (flag[i])
						B.setTable(anyPlayer[i], (seats[i] - 1));

				cout << "Let's Play!" << endl;
				B.startGame();
				for (int i = 0;i < numOfPlayers;i++)
					sum[i] = 0;
				for (int i = 0;i < numOfPlayers;i++)
					if (anyPlayer[i].getHand(0) != NULL)
						sum[i] = anyPlayer[i].getHand(0)->getProfit();
				for (int i = 0;i < numOfPlayers;i++)
					newMoney[i] += sum[i];

				for (int i = 0;i < numOfPlayers;i++)
					if (newMoney[i] < minBet)
					{
						cout << "no enough money for " << anyPlayer[i].getName() << endl;
						flag[i] = false;
						B.removePlayer(seats[i] - 1);
					}

				if (!flag[0] && !flag[1] && !flag[2])
					break;
				cout << "Another one ? yes press 1, no 0" << endl;
				cin >> decision;
				if (decision == 0)
					break;
				for (int i = 0;i < numOfPlayers;i++)
					if (flag[i])
						money[i] = newMoney[i];
			}
		}
		break;
		case 4:
		{
			int money[4] = {};
			int newMoney[4] = {};
			int sum[4] = {};
			int decision = 1;
			bool flag[4];
			for (int i = 0;i < numOfPlayers;i++)
				flag[i] = true;
			cout << " Player 1 : Insert Name please" << endl;
			cin >> playerName[0];
			cout << "Player 1 : Insert Money please (minimum " << minBet << "$)" << endl;
			cin >> money[0];

			while (money[0] < minBet)
			{
				cout << "minimum " << minBet << endl;
				cin >> money[0];
			}
			cout << "Player 1: choose a seat (1-4)" << endl;
			cin >> seats[0];
			while (!(seats[0] == 1 || seats[0] == 2 || seats[0] == 3 || seats[0] == 4))
			{
				cout << "please insert valid number (1-4)" << endl;
				cin >> seats[0];
			}
			cout << " Player 2 : Insert Name please" << endl;
			cin >> playerName[1];
			cout << "Player 2 : Insert Money please (minimum " << minBet << "$)" << endl;
			cin >> money[1];
			while (money[1] < minBet)
			{
				cout << "minimum " << minBet << endl;
				cin >> money[1];
			}
			cout << "Player 2: choose a seat (1-4)" << endl;
			cin >> seats[1];
			while (seats[0] == seats[1] || !(seats[1] == 1 || seats[1] == 2 || seats[1] == 3 || seats[1] == 4))
			{
				cout << "the seat is occupied/ invalid , choose another except " << seats[0] << endl;
				cin >> seats[1];
			}

			cout << " Player 3 : insert Name please" << endl;
			cin >> playerName[2];
			cout << "Player 3 : insert Money please (minimum " << minBet << "$)" << endl;
			cin >> money[2];
			while (money[2] < minBet)
			{
				cout << "minimum " << minBet << endl;
				cin >> money[2];
			}
			cout << "Player 3: choose a seat (1-4)" << endl;
			cin >> seats[2];
			while (seats[1] == seats[2] || seats[0] == seats[2] || !(seats[2] == 1 || seats[2] == 2 || seats[2] == 3 || seats[2] == 4))
			{
				cout << "the seat is occupied / invalid , choose another except " << seats[1] << " " << seats[0] << endl;
				cin >> seats[2];
			}
			cout << " Player 4 : insert Name please" << endl;
			cin >> playerName[3];
			cout << "Player 4 : insert Money please (minimum " << minBet << "$)" << endl;
			cin >> money[3];
			while (money[3] < minBet)
			{
				cout << "minimum " << minBet << endl;
				cin >> money[3];
			}
			for (int i = 1;i < 5;i++)
			{
				if (!(i == seats[2] || i == seats[1] || i == seats[0]))
					seats[3] = i;
			}
			for (int i = 0;i < numOfPlayers;i++)
				newMoney[i] = money[i];
		
			while (decision)
			{
				
				Player anyPlayer[4] = { Player(minBet,playerName[0],money[0]),Player(minBet,playerName[1],money[1]),
					Player(minBet,playerName[2],money[2]),Player(minBet,playerName[3],money[3]) };
				Table B(minBet);

				for(int i=0;i<numOfPlayers;i++)
					if(flag[i])
						B.setTable(anyPlayer[i], (seats[i] - 1));
			
				cout << "Let's Play!" << endl;
				B.startGame();
				for (int i = 0;i < numOfPlayers;i++)
					sum[i] = 0;
				for (int i = 0;i < numOfPlayers;i++)
					if (anyPlayer[i].getHand(0) != NULL)
						sum[i] = anyPlayer[i].getHand(0)->getProfit();
				for (int i = 0;i < numOfPlayers;i++)
					newMoney[i] += sum[i];
			
				for (int i = 0;i < numOfPlayers;i++)
					if (newMoney[i] < minBet)
					{
						cout << "no enough money for " << anyPlayer[i].getName() << endl;
						flag[i] = false;
						B.removePlayer(seats[i] - 1);
					}
			
				if (!flag[0] && !flag[1] && !flag[2] && !flag[3])
					break;
				cout << "Another one ? yes press 1, no 0" << endl;
				cin >> decision;
				if (decision == 0)
					break;
				for (int i = 0;i < numOfPlayers;i++)
					if (flag[i])
						money[i] = newMoney[i];
			}
		}
		break;
		default:
			cout << "GoodBye" << endl;
			return;
			break;
		}
	}
	cout << "GoodBye" << endl;
	return;
}