#include <iostream>
#include <ctime>
#include <cstdlib>
#include <string.h>
#pragma once
using namespace std;

class Hand
{
	bool _canSplit;
	bool _fail;
	bool _win;
	bool _drow;
	int _numOfMoreCards;
	int _card1;
	int _card2;
	int _sumOfCards;
	int _sumOfCardsAce;
	int* _moreCards;
	int _money;
	int _profit;
	
public:
	//getters.
	int getCard1() const
	{
		return this->_card1;
	}
	int getCard2() const
	{
		return this->_card2;
	}
	int getNumOfMoreCards() const
	{
		return this->_numOfMoreCards;
	}
	bool getFail() const
	{
		return this->_fail;
	}
	int getProfit() const
	{
		return this->_profit;
	}
	int getSumOfCards()const
	{
		return this->_sumOfCards;
	}
	int getSumOfCardsAce()const
	{
		return this->_sumOfCardsAce;
	}
	int getMoney() const
	{
		return this->_money;
	}
	bool getCanSplit() const
	{
		return this->_canSplit;
	}
	bool getWin() const
	{
		return this->_win;
	}
	int* getMoreCards()const
	{
		return this->_moreCards;
	}
	bool getDrow() const
	{
		return this->_drow;

	}
	//setters .
	void setDrow(int sumOfDealerCards, int numOfDealerCards);
	void setWin(int sumOfDealerCards,int numOfDealerCards);
	void setHandMoney(double d);
	void setCanSplit();
	void setSumOfCards(int cards);
	void setFail();
	void setProfit(int money);
	void setCards(int card1, int card2);
	int* setMoreCard(bool choice);
	//print hand.
	void printHand(bool beAfter) const;
	//when player ask for erase.
	void eraseHand();
	//replace cards.
	void newCards(int money);
	//know how many cards total.
	void addNumOfMoreCards();
	//split function.
	Hand HandSplit(int card1, int card2);
	//constructors and destructor.
	Hand(int money = 0);
	Hand(const Hand& hand);
	~Hand();

};

