#include "Hand.h"

void Hand::setFail()
{
	this->_fail = false;
	if (this->getSumOfCards() == 0)
	{
		this->_fail = true;
		return;
	}
	else if (this->getSumOfCards() > 21 && this->getSumOfCardsAce() == 0)
	{
		this->_fail = true;
		return;
	}
	else if (this->getSumOfCards() > 21 && this->getSumOfCardsAce() > 21)
	{
		this->_fail = true;
		return;
	}
}
void Hand::setProfit(int money)
{
	this->_profit += money;
}
void Hand::setCards(int card1, int card2)
{
	this->_card1 = card1;
	this->_card2 = card2;
	if (this->getCard2() != 1 && this->getCard1() != 1)
	{
		if (this->getCard2() <= 10 && this->getCard1() <= 10)
			this->_sumOfCards = this->_card2 + this->_card1;
		if (this->getCard2() <= 10 && this->getCard1() > 10)
			this->_sumOfCards = this->_card2 + 10;
		if (this->getCard2() > 10 && this->getCard1() <= 10)
			this->_sumOfCards = this->_card1 + 10;
		if (this->getCard2() > 10 && this->getCard1() > 10)
			this->_sumOfCards = 20;
		this->_sumOfCardsAce = 0;

		return;
	}
	if (this->getCard2() == 1 && this->getCard1() >= 10)
	{
		this->_sumOfCardsAce = 21;
		this->_sumOfCards = 11;
		return;
	}
	if (this->getCard1() == 1 && this->getCard2() >= 10)
	{
		this->_sumOfCardsAce = 21;
		this->_sumOfCards = 11;
		return;
	}
	if (this->getCard1() == 1 && (this->getCard2() < 10 && this->getCard2() > 1))
	{
		this->_sumOfCards = this->_card2 + 1;
		this->_sumOfCardsAce = this->_sumOfCards + 10;
		return;

	}
	if (this->getCard2() == 1 && (this->getCard1() < 10 && this->getCard1() > 1))
	{
		this->_sumOfCards = this->_card1 + 1;
		this->_sumOfCardsAce = this->_sumOfCards + 10;
		return;

	}
	if (this->getCard1() == 1 && this->getCard2() == 1)
	{
		this->_sumOfCards = 2;
		this->_sumOfCardsAce = this->_sumOfCards + 10;
		return;


	}
}
void Hand::eraseHand()
{
	this->setCards(0, 0);
	return;
}
void  Hand::setHandMoney(double d)
{
	this->_money *= d;
}
void Hand::setSumOfCards(int cards)
{
	if (cards > 1 && cards < 10)
	{
		this->_sumOfCards += cards;
		if (this->getSumOfCardsAce() == 0)
			return;
		else
			this->_sumOfCardsAce += cards;

	}
	else if (cards >= 10)
	{
		this->_sumOfCards += 10;
		if (this->getSumOfCardsAce() == 0)
			return;
		else
			this->_sumOfCardsAce += 10;
	}

	else if (cards == 1)
	{
		this->_sumOfCards += 1;
		if (this->getSumOfCardsAce() == 0)
			this->_sumOfCardsAce = this->_sumOfCards + 10;
		else
			this->_sumOfCardsAce += 1;
	}
}
void Hand::setWin(int sumOfDealerCards, int numOfDealerCards)
{
	bool eraseHand = this->getSumOfCards() == 0;
	bool dealerBlackJack = (sumOfDealerCards == 21 && numOfDealerCards == 0);
	bool playerHandBlackJack = this->getSumOfCardsAce() == 21 && this->getNumOfMoreCards() == 0;
	bool dealerFail = sumOfDealerCards > 21;
	this->_win = false;
	if (this->getFail() == true)
	{
		return;
	}
	else if (eraseHand)
	{
		this->_win = false;
		return;
	}
	else if (playerHandBlackJack && !dealerBlackJack)
	{
		this->_win = true;
		return;
	}
	else if ((sumOfDealerCards < this->getSumOfCardsAce() && (21 >= this->getSumOfCardsAce())) || (sumOfDealerCards < this->getSumOfCards() && 21 >= this->getSumOfCards()))
	{
		this->_win = true;
		return;
	}
	else if (dealerFail)
	{
		this->_win = true;
		return;
	}
	else
		return;
}
void Hand::setDrow(int sumOfDealerCards, int numOfDealerCards)
{
	bool dealerBlackJack = (sumOfDealerCards == 21 && numOfDealerCards == 0);
	bool playerHandBlackJack = this->getSumOfCardsAce() == 21 && this->getNumOfMoreCards() == 0;
	this->_drow = false;
	if (dealerBlackJack && playerHandBlackJack)
	{
		this->_drow = true;
		return;
	}
	else if (dealerBlackJack && !playerHandBlackJack)
	{
		this->_drow = false;
		return;
	}
	else if (sumOfDealerCards == this->getSumOfCardsAce() || sumOfDealerCards == this->getSumOfCards())
	{
		this->_drow = true;
		return;
	}

}
void  Hand::addNumOfMoreCards()
{
	this->_numOfMoreCards += 1;
}
int* Hand::setMoreCard(bool choice)
{
	if (choice == true)
	{
		int* p = new int[(this->getNumOfMoreCards()) + 1];
		if (this->_moreCards != NULL)
			for (int i = 0;i < ((this->getNumOfMoreCards()));i++)
			{
				p[i] = this->_moreCards[i];
			}
		p[((this->getNumOfMoreCards()))] = (rand() % 13) + 1;
		this->_moreCards = p;
		this->addNumOfMoreCards();
		setSumOfCards(this->_moreCards[(this->getNumOfMoreCards()) - 1]);
		return this->_moreCards;
	}
	else
	{
		this->_moreCards = NULL;
		return this->_moreCards;
	}
}
void Hand::setCanSplit()
{
	this->_canSplit = false;
	if (this->_card1 == this->_card2)
		this->_canSplit = true;
	else if ((this->_card1 == 10 || this->_card1 == 11 || this->_card1 == 12 || this->_card1 == 13) && (this->_card2 == 10 || this->_card2 == 11 || this->_card2 == 12 || this->_card2 == 13))
		this->_canSplit = true;
}
void Hand::printHand(bool beAfter) const
{
	int card1 = this->getCard1();
	string cd1 = "X";
	switch (card1)
	{
	case 1:
		cd1 = 'A';
		break;
	case 2:
		cd1 = '2';
		break;
	case 3:
		cd1 = '3';
		break;
	case 4:
		cd1 = '4';
		break;
	case 5:
		cd1 = '5';
		break;
	case 6:
		cd1 = '6';
		break;
	case 7:
		cd1 = '7';
		break;
	case 8:
		cd1 = '8';
		break;
	case 9:
		cd1 = '9';
		break;
	case 10:
		cd1 = "10";
		break;
	case 11:
		cd1 = 'J';
		break;
	case 12:
		cd1 = 'Q';
		break;
	case 13:
		cd1 = 'K';
		break;
	default:
		cd1 = "X";
		break;
	}

	int card2 = this->getCard2();
	string cd2 = "X";
	switch (card2)
	{
	case 1:
		cd2 = 'A';
		break;
	case 2:
		cd2 = '2';
		break;
	case 3:
		cd2 = '3';
		break;
	case 4:
		cd2 = '4';
		break;
	case 5:
		cd2 = '5';
		break;
	case 6:
		cd2 = '6';
		break;
	case 7:
		cd2 = '7';
		break;
	case 8:
		cd2 = '8';
		break;
	case 9:
		cd2 = '9';
		break;
	case 10:
		cd2 = "10";
		break;
	case 11:
		cd2 = 'J';
		break;
	case 12:
		cd2 = 'Q';
		break;
	case 13:
		cd2 = 'K';
		break;
	default:
		cd2 = "X";
		break;
	}

	cout << "Hand money:";
	if (beAfter && this->getMoney() >= 0)
		cout << "+";
	cout<< this->getMoney() << "$" << endl;
	cout << "Cards:" << cd1 << " " << cd2 << " ";
	if (this->getSumOfCardsAce() == 21 && this->getNumOfMoreCards() == 0)
	{
		cout << endl;
		cout << "BlackJack!" << endl;
		return;
	}
	if (this->getMoreCards() != NULL)
	{
		string arr[20];
		for (int k = 0;k < (this->getNumOfMoreCards());k++)
		{

			switch (this->getMoreCards()[k])
			{
			case 1:
				arr[k] = 'A';
				break;
			case 2:
				arr[k] = '2';
				break;
			case 3:
				arr[k] = '3';
				break;
			case 4:
				arr[k] = '4';
				break;
			case 5:
				arr[k] = '5';
				break;
			case 6:
				arr[k] = '6';
				break;
			case 7:
				arr[k] = '7';
				break;
			case 8:
				arr[k] = '8';
				break;
			case 9:
				arr[k] = '9';
				break;
			case 10:
				arr[k] = "10";
				break;
			case 11:
				arr[k] = 'J';
				break;
			case 12:
				arr[k] = 'Q';
				break;
			case 13:
				arr[k] = 'K';
				break;
			default:
				arr[k] = "X";
				break;
			}

		}
		for (int i = 0;i < (this->getNumOfMoreCards());i++)
			cout << arr[i] << "	";
	}
	cout << endl;
	cout << "***************" << endl;
}

void Hand::newCards(int money)
{
	this->_money = money;
	this->setCards((rand() % 13) + 1, (rand() % 13) + 1);
	if (this->getMoreCards() != NULL)
		delete[] _moreCards;
	this->_moreCards = NULL;
	this->setCanSplit();
	this->_numOfMoreCards = 0;
	this->setFail();
}
Hand Hand::HandSplit(int card1, int card2)
{
	Hand A;
	A._money = this->_money;
	A.setCards(card2, (rand() % 13) + 1);
	this->setCards(card1, (rand() % 13) + 1);
	return A;
}
Hand::Hand(int money)
{
	this->setCards((rand() % 13) + 1, (rand() % 13) + 1);
	this->_money = money;
	this->setCanSplit();
}
Hand::Hand(const Hand& hand)
{
	this->_card1 = hand.getCard1();
	this->_card2 = hand.getCard2();
	this->_sumOfCards = hand.getSumOfCards();
	this->_sumOfCardsAce = hand.getSumOfCardsAce();
	this->_money = hand.getMoney();
	this->_canSplit = hand.getCanSplit();
	this->_fail = hand.getFail();
	this->_win = hand.getWin();
	this->_drow = hand.getDrow();
	this->_profit = hand.getProfit();
	if (hand.getMoreCards()) {
		this->_moreCards = new int[hand.getNumOfMoreCards()];
		for (int i = 0; i < hand.getNumOfMoreCards();i++)
			this->_moreCards[i] = hand.getMoreCards()[i];
	}
	else
		this->_moreCards = NULL;
}
Hand::~Hand()
{
	if (this->getMoreCards() != NULL)
		delete[] this->_moreCards;
}