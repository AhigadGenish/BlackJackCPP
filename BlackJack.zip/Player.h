#include "Hand.h"

class Player
{
	string _name;
	Hand* _hands[2];
	bool _splitChoice;
	bool _insuranceChoice;
	int _totalMoney;
	int _minBet;
	int _moneyInsurance;
	static int _numOfPlayers;

public:
	//getters.
	int getTotalMoney() const
	{
		return this->_totalMoney;
	}
	int getMoneyInsurance() const {
		return this->_moneyInsurance;
	}
	bool getInsuranceChoice() const {
		return this->_insuranceChoice;
	}
	Hand* getHand(int i) const
	{
		return this->_hands[i];

	}
	Hand& getTheHand(int i) const
	{
		return *this->_hands[i];

	}
	
	int getMinBet() const
	{
		return this->_minBet;
	}
	bool getSplitChoice() const
	{
		return this->_splitChoice;
	}
	string getName() const
	{
		return this->_name;
	}
	int getNumofPlayers()const
	{
		return this->_numOfPlayers;
	}
	//setters
	void setMoneyInsurance(double mul);
	void setMinBet(int min);
	void setTotalMoney(int money);
	void setName(string name);
	void setSplitChoice();
	void setInsuranceChoice();
	void setSplit();
	bool setPlayer(int money, int min);
	//print Player.
	void printPlayer(bool beAfter);
	//calaculate total money after dealer play.
	void calculateMoney();
	//replace cards.
	void setNewHand(int money);
	//validation.
	bool canPlay() const;
	//more card.
	bool moreCard(Hand& hand, int decision);
	//check for split hand.
	void checkSplit();
	//decision of player during play.
	int decision(Hand& hand);
	int decisionAfter(Hand& hand);
	//constructor and destructor.
	Player(int min = 500 , string name = "user", int money = 500);
	~Player();

};

